document.addEventListener('DOMContentLoaded', () => {
    handleForms();
});

function handleForms() {
    const forms = document.querySelectorAll('form');

    forms.forEach(form => {
        form.addEventListener('submit', event => {
            event.preventDefault();

            const formData = {
                name: form.elements.name.value,
                email: form.elements.email.value,
                phone: form.elements.phone.value,
                comment: form.elements.comment ? form.elements.comment.value : null,
                howCanWeHelp: form.elements.howCanWeHelp ? form.elements.howCanWeHelp.value : null,
                address: form.elements.address ? form.elements.address.value : null,
                city: form.elements.city ? form.elements.city.value : null,
                region: form.elements.region ? form.elements.region.value : null,

                // Checkboxes
                landscapeCheckbox: form.elements.landscapeCheckbox && form.elements.landscapeCheckbox.checked ? true : false,
                lightingCheckbox: form.elements.lightingCheckbox && form.elements.lightingCheckbox.checked ? true : false,
                hardscapeCheckbox: form.elements.hardscapeCheckbox && form.elements.hardscapeCheckbox.checked ? true : false,
                poolCheckbox: form.elements.poolCheckbox && form.elements.poolCheckbox.checked ? true : false,
                maintenaceCheckbox: form.elements.maintenaceCheckbox && form.elements.maintenaceCheckbox.checked ? true : false,
                artificialTurfCheckbox: form.elements.artificialTurfCheckbox && form.elements.artificialTurfCheckbox.checked ? true : false,
            }

			fetch('form.php', {
                method: 'POST',
                body: JSON.stringify(formData),
                headers: {
                  'Content-type': 'application/json; charset=UTF-8',
                }
          })
          .then((response) => response.json())
          .then((emailSent) => {
            const alertSuccess = document.querySelector('#modalForm .alert-success');
            const alertDanger = document.querySelector('#modalForm .alert-danger');

            if (!alertSuccess.classList.contains('d-none')) alertSuccess.classList.add('d-none');
            if (!alertDanger.classList.contains('d-none')) alertDanger.classList.add('d-none');

            if (emailSent) {
                alertSuccess.classList.remove('d-none');
            } else {
                alertDanger.classList.remove('d-none');
            }

            document.querySelector('#buttonModalForm').click();
          }).catch(error => console.error('Error:', error));
        })
    });
}

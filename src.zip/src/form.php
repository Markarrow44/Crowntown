<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
$restJson = file_get_contents('php://input');
$_POST = json_decode($restJson, true);

// HTML email headers
$headers = "MIME-Version: 1.0" . "\r\n"; 
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n"; 
 
// Additional headers 
$headers .= 'From: '. $_POST['name'] . '<'.$_POST['email'].'>' . "\r\n"; 

// Subject
$subject = 'New message from CrownTown';

// Message
$message = '';

if ($_POST['name']) $message .= '<b>Name:</b> ' . $_POST['name'] . '<br>';
if ($_POST['email']) $message .= '<br><b>Email</b>: ' . $_POST['email'] . '<br>';
if ($_POST['phone']) $message .= '<br><b>Phone</b>: ' . $_POST['phone'] . '<br>';
if ($_POST['comment']) $message .= '<br><b>Comment</b>: ' . $_POST['comment'] . '<br>';
if ($_POST['howCanWeHelp']) $message .= '<br><b>How can we help</b>: ' . $_POST['howCanWeHelp'] . '<br>';
if ($_POST['address']) $message .= '<br><b>Address</b>: ' . $_POST['address'] . '<br>';
if ($_POST['city']) $message .= '<br><b>City</b>: ' . $_POST['city'] . '<br>';
if ($_POST['region']) $message .= '<br><b>Region</b>: ' . $_POST['region'] . '<br>';

// Checkboxes
if ($_POST['landscapeCheckbox'] || $_POST['lightingCheckbox'] || $_POST['hardscapeCheckbox'] || $_POST['poolCheckbox'] || $_POST['maintenaceCheckbox'] || $_POST['artificialTurfCheckbox']) {
    $message .= '<br><b>Services:</b> <ul style="margin-bottom: 0 !important;">';
    if ($_POST['landscapeCheckbox']) $message .= '<li>Landscape</li>';
    if ($_POST['lightingCheckbox']) $message .= '<li>Lighting</li>';
    if ($_POST['hardscapeCheckbox']) $message .= '<li>Hardscape</li>';
    if ($_POST['poolCheckbox']) $message .= '<li>Pool</li>';
    if ($_POST['maintenaceCheckbox']) $message .= '<li>Maintenace</li>';
    if ($_POST['artificialTurfCheckbox']) $message .= '<li>Artificial</li>';
    $message .= '</ul>';
}

if (mail('markarrow300@gmail.com', $subject, $message, $headers)) {
    echo json_encode(true);
} else {
    echo json_encode(false); 
}
?>
